# Raport projektu — bezpieczny chatbot RAG IDEIS

## Temat i źródło

Indeks `13897 → 28 → 10 → 1`, więc zrealizowano asystenta regulaminu studiów.
Baza wiedzy używa oficjalnego regulaminu Uniwersytetu DSW Ideis, będącego załącznikiem
do uchwały Senatu nr 106/2025 i obowiązującego od roku akademickiego 2025/2026:

<https://www.ideis.pl/krakow/sites/ideis_krakow/files/2026-04/regulamin_studiow.pdf>

PDF podzielono na 58 fragmentów z metadanymi stron. Aktywny indeks nie zawiera
wcześniejszego przykładowego regulaminu Akademii WSB.

## Uruchomienie

Po rozpakowaniu paczki uruchom:

```text
Uruchom_Chatbot_IDEIS.exe
```

Launcher automatycznie:

- instaluje Python 3.12, jeżeli system go nie ma;
- tworzy `.venv` i instaluje zależności;
- sprawdza lub instaluje Ollamę;
- pobiera Bielika 1.5B i `nomic-embed-text`;
- testuje generację i omija wadliwy backend CUDA przez `cpu_avx2`;
- pyta lokalnie o token Telegram i opcjonalny token Hugging Face;
- buduje bazę RAG;
- udostępnia menu Telegrama, demo, testów i diagnostyki.

Token Telegrama jest wymagany do połączenia z Telegramem, ale nie należy przesyłać go
w rozmowie. Launcher pobiera go lokalnie i sprawdza przez metodę `getMe` API Telegrama.

## Zweryfikowane granice

- tylko pytania dotyczące regulaminu IDEIS;
- maksymalnie 4000 znaków, odrzucenie pustych danych;
- maskowanie PII przed RAG, LLM i logowaniem;
- klasyfikacja bezpieczeństwa oraz osobna reguła spamu;
- blokowanie prompt injection;
- odmowa przy niewystarczającym kontekście;
- walidacja liczb, procedur i pokrycia odpowiedzi kontekstem;
- deterministyczne odpowiedzi dla szczególnie podatnych na halucynacje pytań
  regulaminowych;
- filtr PII i bezpieczeństwa również na wyjściu.

Szczegóły: `docs/BOUNDARIES_AND_TESTS.md` w paczce.

## Wyniki testów z 13 lipca 2026 r.

```text
11/11 testów jednostkowych                    OK
36/36 testów granic i nadużyć                 OK
8/8 testów live faktów regulaminowych         OK
1/1 test prawdziwej generacji Ollama          OK
```

Pierwszy test generatora wykrył rzeczywisty błąd CUDA: model Ollama kończył proces z
komunikatem o nieobsługiwanym PTX. Po uruchomieniu oficjalnie wspieranego wariantu
`OLLAMA_LLM_LIBRARY=cpu_avx2` model odpowiedział poprawnie. Launcher wykonuje tę
diagnostykę i naprawę automatycznie.

Testy faktograficzne wykryły początkowe halucynacje małego modelu 1.5B, m.in. wymyślony
formularz i termin odwołania oraz pominięcie części limitu wpisu warunkowego. Dodano
hybrydową warstwę faktów i filtr ugruntowania. Po poprawkach zestaw faktograficzny
przechodzi 8/8.

## Ważne ograniczenie Bielik Guard

Model `speakleash/Bielik-Guard-0.1B-v1.1` ma warunkowy dostęp na Hugging Face. Użytkownik
musi sam zaakceptować warunki modelu i podać launcherowi token `read`. Bez tokenu system
działa z jawnym `heuristic-fallback`; nie udaje, że uruchomił właściwy model.

## Źródła techniczne

- OpenAI Privacy Filter: <https://openai.com/index/introducing-openai-privacy-filter/>
- Model Privacy Filter: <https://huggingface.co/openai/privacy-filter>
- Bielik Guard: <https://huggingface.co/speakleash/Bielik-Guard-0.1B-v1.1>
- Bielik dla Ollama: <https://ollama.com/qooba/bielik-1.5b-v3.0-instruct>
- Rozwiązywanie problemów Ollama: <https://docs.ollama.com/troubleshooting>
